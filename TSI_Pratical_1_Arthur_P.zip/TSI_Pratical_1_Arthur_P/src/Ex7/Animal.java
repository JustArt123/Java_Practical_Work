package Ex7;

public interface Animal {
    void sound();
}
