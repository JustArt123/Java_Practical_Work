package Ex7;

public interface Domestic {
    void printName();
}
