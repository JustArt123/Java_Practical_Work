package Ex7;

public interface Wild {
    void printName();
}
