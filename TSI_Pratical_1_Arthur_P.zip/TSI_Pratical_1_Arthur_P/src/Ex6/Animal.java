package Ex6;

public interface Animal {
    void sound();
}
