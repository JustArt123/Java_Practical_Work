package Ex6;

public class Cat implements Animal{

    @Override
    public void sound() {
        System.out.println("Meow");
    }
}
