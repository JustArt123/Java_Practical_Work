package com.tsi.java;

public class Variable {
    // String variable with value
    public String fullName = "TSI JAVA!";

    // Integer variable with value
    int number = 100;

    // long
    long longNumber = 123456789;

    // Double variable with value
    double numberWithDecimal;

    // Float variable with value
    float floatNumber;

    // Boolean variable
    boolean isWorkday;

    // char
    char myChar = 'a';

    // for int, Integer
    Integer myInteger = 75;

    // Double
    Double myDouble = 75.75;

    // Float
    Float myFloat = 85.85F;

    // Long
    Long myLongNumber = 12345678L;

    // Char
    Character myCharacter = 'b';

    int result = number + 50;


}
