package com.tsi.java;

public class Functions {


    public int add(int a, int b, int c) {

        int result = a + b + c;

        return result;
    }

    public void print(String message) {
        System.out.println(message);
    }
}
