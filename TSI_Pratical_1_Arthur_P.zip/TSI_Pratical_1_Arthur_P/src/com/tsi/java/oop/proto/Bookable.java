package com.tsi.java.oop.proto;

public interface Bookable {
    String getName();
}
