package com.tsi.java.oop.proto;

public interface Payable {
    double getPrice();
}
