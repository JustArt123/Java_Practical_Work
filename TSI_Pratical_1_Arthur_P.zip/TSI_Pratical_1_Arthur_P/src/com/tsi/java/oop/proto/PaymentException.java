package com.tsi.java.oop.proto;

public class PaymentException extends RuntimeException{

    public PaymentException(String message) {
        super(message);
    }
}
