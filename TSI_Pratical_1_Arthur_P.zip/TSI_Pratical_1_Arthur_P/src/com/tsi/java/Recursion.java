package com.tsi.java;

public class Recursion {

    public void recursion(int num) {
        if (num == 0) {
            return;
        }
        recursion(num - 1);
        System.out.println(num);
    }


    //: f = N! = 1 * 2 * 3 * ... * N;
    // f! = N! = N * (N-1)!
    public long factorialRec(int num) {
        if (num == 0) {
            return 1;
        }

        return num * factorialRec(num - 1);
    }

    // fact 5 = 5 * 4 * 3 * 2 * 1
    public long factorialLoop(int num) {
        long fact = num;
        for (int i = num - 1; i > 0; i--) {
            fact *= i;
        }

        return fact;
    }


    public static void main(String[] args) {
        Recursion recursion = new Recursion();

        long result = recursion.factorialLoop(5);

        System.out.println("Factorial: " + result);
    }

}
