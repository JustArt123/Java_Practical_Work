package com.example.Practical5.model;

public enum ProductType {
    COMPUTERS,
    SMARTPHONES,
    SMART_HOME_DEVICES;
}
