package com.isep.practical4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Practical4ApplicationTests {

    @Test
    void contextLoads() {
    }

}
