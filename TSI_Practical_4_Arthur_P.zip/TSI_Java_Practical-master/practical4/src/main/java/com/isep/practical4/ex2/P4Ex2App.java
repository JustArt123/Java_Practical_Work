package com.isep.practical4.ex2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class P4Ex2App {

    public static void main(String[] args) {
        SpringApplication.run(P4Ex2App.class, args);
    }

}