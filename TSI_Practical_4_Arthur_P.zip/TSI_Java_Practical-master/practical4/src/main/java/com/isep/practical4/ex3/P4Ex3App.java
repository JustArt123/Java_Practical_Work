package com.isep.practical4.ex3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class P4Ex3App {

    public static void main(String[] args) {
        SpringApplication.run(P4Ex3App.class, args);
    }

}