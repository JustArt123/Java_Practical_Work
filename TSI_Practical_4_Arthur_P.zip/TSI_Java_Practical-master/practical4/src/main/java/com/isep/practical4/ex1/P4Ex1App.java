package com.isep.practical4.ex1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class P4Ex1App {

    public static void main(String[] args) {
        SpringApplication.run(com.isep.practical4.ex1.P4Ex1App.class, args);
    }

}
